package com.futureai.editor

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private var selectedVideo: Uri? = null
    private lateinit var status: TextView
    private val pickVideo = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 42, 36, 36)
            setBackgroundColor(0xFF10131B.toInt())
        }

        val title = TextView(this).apply {
            text = "FUTURE AI EDITOR"
            textSize = 25f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "আপনার ভিডিও ও স্ক্রিপ্ট এক জায়গায়"
            textSize = 15f
            setTextColor(0xFFB8C2D8.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 28)
        }
        root.addView(subtitle, matchWrap())

        val pick = Button(this).apply {
            text = "ভিডিও নির্বাচন করুন"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply { type = "video/*" }
                startActivityForResult(Intent.createChooser(intent, "ভিডিও নির্বাচন করুন"), pickVideo)
            }
        }
        root.addView(pick, matchWrap())

        status = TextView(this).apply {
            text = "এখনো কোনো ভিডিও নির্বাচন করা হয়নি"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 18, 0, 18)
        }
        root.addView(status, matchWrap())

        val scriptLabel = TextView(this).apply {
            text = "ভিডিওর স্ক্রিপ্ট / আইডিয়া"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
        }
        root.addView(scriptLabel, matchWrap())

        val script = EditText(this).apply {
            hint = "এখানে বাংলায় বা ইংরেজিতে আপনার ভিডিওর আইডিয়া লিখুন..."
            minLines = 5
            gravity = Gravity.TOP
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9AA4B8.toInt())
            setBackgroundColor(0xFF222838.toInt())
            setPadding(18, 16, 18, 16)
        }
        root.addView(script, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val save = Button(this).apply {
            text = "নির্বাচিত ভিডিও কপি করে সেভ করুন"
            setOnClickListener { saveVideoCopy() }
        }
        root.addView(save, matchWrap())

        val note = TextView(this).apply {
            text = "প্রাথমিক সংস্করণ: ভিডিও নির্বাচন, স্ক্রিপ্ট লেখা এবং ভিডিও কপি করে সেভ করা যায়। AI ভিডিও জেনারেশন, ভয়েস ও উন্নত এডিটিং পরবর্তী সংস্করণে যোগ করতে হবে।"
            textSize = 12f
            setTextColor(0xFFB8C2D8.toInt())
            setPadding(0, 18, 0, 0)
        }
        root.addView(note, matchWrap())

        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    @Deprecated("Deprecated in Android but retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickVideo && resultCode == RESULT_OK) {
            selectedVideo = data?.data
            status.text = if (selectedVideo != null) "ভিডিও নির্বাচন করা হয়েছে ✓" else "ভিডিও নির্বাচন হয়নি"
        }
    }

    private fun saveVideoCopy() {
        val uri = selectedVideo
        if (uri == null) {
            Toast.makeText(this, "আগে একটি ভিডিও নির্বাচন করুন", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val folder = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir
            val output = File(folder, "FutureAI_${System.currentTimeMillis()}.mp4")
            contentResolver.openInputStream(uri).use { input ->
                if (input == null) throw IllegalStateException("ভিডিও পড়া যাচ্ছে না")
                FileOutputStream(output).use { out -> input.copyTo(out) }
            }
            Toast.makeText(this, "ভিডিও সেভ হয়েছে: ${output.name}", Toast.LENGTH_LONG).show()
            status.text = "সেভ সম্পন্ন ✓\n${output.absolutePath}"
        } catch (e: Exception) {
            Toast.makeText(this, "সেভ করা যায়নি: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
