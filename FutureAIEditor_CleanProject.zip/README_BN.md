# Future AI Editor — Clean Android Project

## এই সংস্করণে যা আছে
- Android অ্যাপের প্রাথমিক UI
- ফোন থেকে ভিডিও নির্বাচন
- বাংলা/ইংরেজি স্ক্রিপ্ট বা আইডিয়া লেখার ঘর
- নির্বাচিত ভিডিও অ্যাপের Movies ফোল্ডারে কপি করে সেভ

## যা এখনো নেই
AI prompt-to-video generation, AI male/female voice, automatic subtitles, multi-track timeline,
transitions, filters, music mixing, trimming/rendering controls, এবং social-media export presets।
এগুলো পরবর্তী সংস্করণে যোগ করতে হবে।

## GitHub-এ আপলোড
ZIP extract করে এর ভেতরের সব ফাইল ও `.github` ফোল্ডারসহ repository-র root-এ আপলোড করুন।
ZIP ফাইলটিকে একা repository-তে আপলোড করলে GitHub Actions project build করতে পারবে না।

## APK build
GitHub-এ ফাইল commit করার পর Actions tab খুলুন। `Build Future AI Editor APK` workflow রান হবে।
সফল হলে workflow run-এর Artifacts অংশ থেকে `FutureAIEditor-debug-apk` ডাউনলোড করুন।
